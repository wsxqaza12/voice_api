# GPT-SoVITS API

This package provides a Python wrapper for the Voice API, allowing easy interaction with the GPT-SoVITS voice synthesis system.

## Installation

```
pip install voice_api
```

## Usage

```python
from voice_api import VoiceAPI

api = VoiceAPI()
api.set_model("woman1")  # or "man1"
```

## Configuration

Edit the `config.py` file to modify model paths and API settings.

## Running Tests

```
python -m unittest discover tests
```